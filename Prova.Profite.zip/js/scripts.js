/*
 *  jQuery Teste Profite
 *
 */

/* jQuery Easing v1.3 - http://gsgd.co.uk/sandbox/jquery/easing/ */
jQuery.easing.jswing = jQuery.easing.swing, jQuery.extend(jQuery.easing, { def: "easeOutQuad", swing: function (n, e, t, u, a) { return jQuery.easing[jQuery.easing.def](n, e, t, u, a) }, easeInQuad: function (n, e, t, u, a) { return u * (e /= a) * e + t }, easeOutQuad: function (n, e, t, u, a) { return -u * (e /= a) * (e - 2) + t }, easeInOutQuad: function (n, e, t, u, a) { return (e /= a / 2) < 1 ? u / 2 * e * e + t : -u / 2 * (--e * (e - 2) - 1) + t }, easeInCubic: function (n, e, t, u, a) { return u * (e /= a) * e * e + t }, easeOutCubic: function (n, e, t, u, a) { return u * ((e = e / a - 1) * e * e + 1) + t }, easeInOutCubic: function (n, e, t, u, a) { return (e /= a / 2) < 1 ? u / 2 * e * e * e + t : u / 2 * ((e -= 2) * e * e + 2) + t }, easeInQuart: function (n, e, t, u, a) { return u * (e /= a) * e * e * e + t }, easeOutQuart: function (n, e, t, u, a) { return -u * ((e = e / a - 1) * e * e * e - 1) + t }, easeInOutQuart: function (n, e, t, u, a) { return (e /= a / 2) < 1 ? u / 2 * e * e * e * e + t : -u / 2 * ((e -= 2) * e * e * e - 2) + t }, easeInQuint: function (n, e, t, u, a) { return u * (e /= a) * e * e * e * e + t }, easeOutQuint: function (n, e, t, u, a) { return u * ((e = e / a - 1) * e * e * e * e + 1) + t }, easeInOutQuint: function (n, e, t, u, a) { return (e /= a / 2) < 1 ? u / 2 * e * e * e * e * e + t : u / 2 * ((e -= 2) * e * e * e * e + 2) + t }, easeInSine: function (n, e, t, u, a) { return -u * Math.cos(e / a * (Math.PI / 2)) + u + t }, easeOutSine: function (n, e, t, u, a) { return u * Math.sin(e / a * (Math.PI / 2)) + t }, easeInOutSine: function (n, e, t, u, a) { return -u / 2 * (Math.cos(Math.PI * e / a) - 1) + t }, easeInExpo: function (n, e, t, u, a) { return 0 == e ? t : u * Math.pow(2, 10 * (e / a - 1)) + t }, easeOutExpo: function (n, e, t, u, a) { return e == a ? t + u : u * (-Math.pow(2, -10 * e / a) + 1) + t }, easeInOutExpo: function (n, e, t, u, a) { return 0 == e ? t : e == a ? t + u : (e /= a / 2) < 1 ? u / 2 * Math.pow(2, 10 * (e - 1)) + t : u / 2 * (-Math.pow(2, -10 * --e) + 2) + t }, easeInCirc: function (n, e, t, u, a) { return -u * (Math.sqrt(1 - (e /= a) * e) - 1) + t }, easeOutCirc: function (n, e, t, u, a) { return u * Math.sqrt(1 - (e = e / a - 1) * e) + t }, easeInOutCirc: function (n, e, t, u, a) { return (e /= a / 2) < 1 ? -u / 2 * (Math.sqrt(1 - e * e) - 1) + t : u / 2 * (Math.sqrt(1 - (e -= 2) * e) + 1) + t }, easeInElastic: function (n, e, t, u, a) { var r = 1.70158, i = 0, s = u; if (0 == e) return t; if (1 == (e /= a)) return t + u; if (i || (i = .3 * a), s < Math.abs(u)) { s = u; var r = i / 4 } else var r = i / (2 * Math.PI) * Math.asin(u / s); return -(s * Math.pow(2, 10 * (e -= 1)) * Math.sin(2 * (e * a - r) * Math.PI / i)) + t }, easeOutElastic: function (n, e, t, u, a) { var r = 1.70158, i = 0, s = u; if (0 == e) return t; if (1 == (e /= a)) return t + u; if (i || (i = .3 * a), s < Math.abs(u)) { s = u; var r = i / 4 } else var r = i / (2 * Math.PI) * Math.asin(u / s); return s * Math.pow(2, -10 * e) * Math.sin(2 * (e * a - r) * Math.PI / i) + u + t }, easeInOutElastic: function (n, e, t, u, a) { var r = 1.70158, i = 0, s = u; if (0 == e) return t; if (2 == (e /= a / 2)) return t + u; if (i || (i = .3 * a * 1.5), s < Math.abs(u)) { s = u; var r = i / 4 } else var r = i / (2 * Math.PI) * Math.asin(u / s); return 1 > e ? -.5 * s * Math.pow(2, 10 * (e -= 1)) * Math.sin(2 * (e * a - r) * Math.PI / i) + t : s * Math.pow(2, -10 * (e -= 1)) * Math.sin(2 * (e * a - r) * Math.PI / i) * .5 + u + t }, easeInBack: function (n, e, t, u, a, r) { return void 0 == r && (r = 1.70158), u * (e /= a) * e * ((r + 1) * e - r) + t }, easeOutBack: function (n, e, t, u, a, r) { return void 0 == r && (r = 1.70158), u * ((e = e / a - 1) * e * ((r + 1) * e + r) + 1) + t }, easeInOutBack: function (n, e, t, u, a, r) { return void 0 == r && (r = 1.70158), (e /= a / 2) < 1 ? u / 2 * e * e * (((r *= 1.525) + 1) * e - r) + t : u / 2 * ((e -= 2) * e * (((r *= 1.525) + 1) * e + r) + 2) + t }, easeInBounce: function (n, e, t, u, a) { return u - jQuery.easing.easeOutBounce(n, a - e, 0, u, a) + t }, easeOutBounce: function (n, e, t, u, a) { return (e /= a) < 1 / 2.75 ? 7.5625 * u * e * e + t : 2 / 2.75 > e ? u * (7.5625 * (e -= 1.5 / 2.75) * e + .75) + t : 2.5 / 2.75 > e ? u * (7.5625 * (e -= 2.25 / 2.75) * e + .9375) + t : u * (7.5625 * (e -= 2.625 / 2.75) * e + .984375) + t }, easeInOutBounce: function (n, e, t, u, a) { return a / 2 > e ? .5 * jQuery.easing.easeInBounce(n, 2 * e, 0, u, a) + t : .5 * jQuery.easing.easeOutBounce(n, 2 * e - a, 0, u, a) + .5 * u + t } });

/*! hoverIntent v1.8.0 // 2014.06.29 // jQuery v1.9.1+ */
(function ($) { $.fn.hoverIntent = function (handlerIn, handlerOut, selector) { var cfg = { interval: 100, sensitivity: 6, timeout: 0 }; if (typeof handlerIn === "object") { cfg = $.extend(cfg, handlerIn) } else { if ($.isFunction(handlerOut)) { cfg = $.extend(cfg, { over: handlerIn, out: handlerOut, selector: selector }) } else { cfg = $.extend(cfg, { over: handlerIn, out: handlerIn, selector: handlerOut }) } } var cX, cY, pX, pY; var track = function (ev) { cX = ev.pageX; cY = ev.pageY }; var compare = function (ev, ob) { ob.hoverIntent_t = clearTimeout(ob.hoverIntent_t); if (Math.sqrt((pX - cX) * (pX - cX) + (pY - cY) * (pY - cY)) < cfg.sensitivity) { $(ob).off("mousemove.hoverIntent", track); ob.hoverIntent_s = true; return cfg.over.apply(ob, [ev]) } else { pX = cX; pY = cY; ob.hoverIntent_t = setTimeout(function () { compare(ev, ob) }, cfg.interval) } }; var delay = function (ev, ob) { ob.hoverIntent_t = clearTimeout(ob.hoverIntent_t); ob.hoverIntent_s = false; return cfg.out.apply(ob, [ev]) }; var handleHover = function (e) { var ev = $.extend({}, e); var ob = this; if (ob.hoverIntent_t) { ob.hoverIntent_t = clearTimeout(ob.hoverIntent_t) } if (e.type === "mouseenter") { pX = ev.pageX; pY = ev.pageY; $(ob).on("mousemove.hoverIntent", track); if (!ob.hoverIntent_s) { ob.hoverIntent_t = setTimeout(function () { compare(ev, ob) }, cfg.interval) } } else { $(ob).off("mousemove.hoverIntent", track); if (ob.hoverIntent_s) { ob.hoverIntent_t = setTimeout(function () { delay(ev, ob) }, cfg.timeout) } } }; return this.on({ "mouseenter.hoverIntent": handleHover, "mouseleave.hoverIntent": handleHover }, cfg.selector) } })(jQuery);


$(document).ready(function () {

    var HOME = {
        left_menu: {},
        init: function () {
            HOME.banner();
            HOME.verCarrinho();
            HOME.carregarColecao();
            HOME.acoesTeste();
        },
        banner: function () {
            $('#wbmSlider').owlCarousel({
                items: 1,
                singleItem: true,
                navigation: true,
                slideSpeed: 300,
                paginationSpeed: 400,
                autoPlay: 8000
            });
        },

        verCarrinho: function () {
            $('#carrinho').hoverIntent({
                sensitivity: 3, // number = sensitivity threshold (must be 1 or higher)
                interval: 60, // number = milliseconds of polling interval
                over: function () {
                    $(this).find('.drop_cart').slideDown(800, "easeOutExpo");
                },
                timeout: 500,
                out: function () {
                    $(this).find('.drop_cart').slideUp(800, "easeOutExpo");
                }
            });
        },

        acoesTeste: function () {
            $('#btnCadastrar').click(function(){
                alert('Cadastrado com sucesso!!');
                console.log('cadastrado com sucesso!!');
            });

            $('.btn-buscar').click(function () {
                alert('Buscando...');
                console.log('Buscando...');
            });

            $('#search').bind('keypress', function (e) {
                if (e.keyCode == 13) {
                    alert('Buscando...');
                    console.log('Buscando...');
                }
            });
        },

        carregarColecao: function () {

            $.getJSON("http://webmoment.com.br/profite/produtos.json", function (jsonProduto) {
                var str = '<h2>' + jsonProduto.NomeColecao + '</h2>';

                str += '<ul class="wbm-colecao">';

                jQuery.each(jsonProduto.Produtos, function () {
                    var produto = this;

                    str += '<li class="wbm-2 produto">';

                    str += '    <div class="imagem">';

                    if (produto.Flag.FreteGratis == true) {
                        str += '        <span class="flag frete-gratis"></span>';
                    }

                    if (produto.Flag.Novidade == true) {
                        str += '        <span class="flag novidade"></span>';
                    }

                    str += '    <a class="link-produto" href="' + produto.Url + '">';
                    str += '        <img src="' + produto.UrlImagem + '" width="180" height="180" alt="' + produto.Nome + '" />';
                    str += '    </a>';
                    str += '    </div>';
                    str += '    <div class="info">';
                    str += '         <a class="link-produto" href="' + produto.Url + '">';
                    str += '            <span class="avaliacao avaliacao-' + produto.Avaliacao + '"></span>';
                    str += '            <h3 class="nome">' + produto.Nome + '</h3>';
                    str += '            <span class="preco">';
                    if (produto.PrecoDeSemFormatacao != produto.PrecoPorSemFormatacao) {
                        str += '                <span class="preco-de">' + produto.PrecoDe + '</span>';
                    }
                    str += '                <span class="preco-por">' + produto.PrecoPor + '</span>';
                    if (produto.Parcelamento > 1) {
                        str += '                <span class="preco-ou">ou <strong>' + produto.Parcelamento + ' x </strong> de <strong>' + produto.ValorParcelas + '</strong></span>';
                    }
                    str += '            </span>';
                    str += '         </a>';
                    str += '    </div>';
                    str += '    <div class="botao-comprar">';
                    str += '         <a class="btn btn-comprar" valor="' + produto.PrecoPorSemFormatacao + '" title="Adicione seu produto ao carrinho">Adicionar ao Carrinho</a>';
                    str += '    </div>';
                    str += '    </li>';

                });

                str += '</ul>';
                
                //escreve no html
                jQuery('#colecao-mais-comprados').html(str);

                $('.botao-comprar a.btn').click(function () {
                    var btn = jQuery(this);

                    var totalProdutos = parseInt(jQuery('#carrinho span.total-itens').html());
                    var valortotal = moedaParaNumero(jQuery('#carrinho span.valor-total').html());
                    totalProdutos += 1;
                    valortotal = numeroParaMoeda(parseInt(btn.attr('valor')) + valortotal);

                    jQuery('#carrinho span.total-itens').html(totalProdutos);
                    jQuery('#carrinho span.valor-total').html('R$ ' + valortotal)

                    alert('Produto cadastrado com sucesso...');
                    console.log('Produto cadastrado com sucesso...');



                });

            });
        }
    }

    HOME.init();
});

function numeroParaMoeda(n, c, d, t) {
    c = isNaN(c = Math.abs(c)) ? 2 : c, d = d == undefined ? "," : d, t = t == undefined ? "." : t, s = n < 0 ? "-" : "", i = parseInt(n = Math.abs(+n || 0).toFixed(c)) + "", j = (j = i.length) > 3 ? j % 3 : 0;
    return s + (j ? i.substr(0, j) + t : "") + i.substr(j).replace(/(\d{3})(?=\d)/g, "$1" + t) + (c ? d + Math.abs(n - i).toFixed(c).slice(2) : "");
}

function moedaParaNumero(valor) {
    return isNaN(valor) == false ? parseFloat(valor) : parseFloat(valor.replace("R$", "").replace(".", "").replace(",", "."));
}

